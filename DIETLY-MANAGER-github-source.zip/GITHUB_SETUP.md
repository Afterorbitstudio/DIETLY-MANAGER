# DIETLY MANAGER — GitHub Setup

## What is included

This archive contains the Expo Router / React Native / TypeScript source for the DIETLY MANAGER B2B owner dashboard, including:

- Animated DIETLY MANAGER opening screen
- Google OAuth entry action
- Email/password prototype owner entry flow
- Orders, Members, Inbox, and Dispatch modules
- Local mock persistence and operational mutations
- Expo configuration and branded assets

## Push to GitHub

1. Create an empty GitHub repository.
2. Extract this archive.
3. Open a terminal in the extracted folder.
4. Install dependencies:

```bash
pnpm install
```

5. Start the Expo web/mobile development server:

```bash
pnpm dev
```

6. Add your GitHub repository as the remote and push:

```bash
git init
git add .
git commit -m "Initial DIETLY MANAGER app"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git
git push -u origin main
```

## Important

- `node_modules`, `.git`, local build output, screenshots, and secret environment files are intentionally excluded.
- The email/password flow is a prototype local owner session. Connect it to a production authentication provider before using it for real users.
- The browser QR preview is separate from this source archive and is not required for GitHub.
