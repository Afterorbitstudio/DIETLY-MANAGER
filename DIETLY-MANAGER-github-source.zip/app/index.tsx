import { Ionicons } from "@expo/vector-icons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useRouter } from "expo-router";
import { useEffect, useState } from "react";
import {
  Animated,
  Easing,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import * as Auth from "@/lib/_core/auth";
import { startOAuthLogin } from "@/constants/oauth";

const SLATE = "#1E252D";
const MINT = "#7CFFB2";
const WHITE = "#F7FBF8";
const MUTED = "#A5B1B7";
const OWNER_SESSION_KEY = "dietly-manager-owner-session";

type Stage = "intro" | "auth";

function BrandMark({ compact = false }: { compact?: boolean }) {
  const [loop] = useState(() => new Animated.Value(0));
  const [beat] = useState(() => new Animated.Value(0));
  const [cloche] = useState(() => new Animated.Value(0));
  const [leaf] = useState(() => new Animated.Value(0));
  const [wordmark] = useState(() => new Animated.Value(0));
  const [manager] = useState(() => new Animated.Value(0));
  const [pulse] = useState(() => new Animated.Value(1));

  useEffect(() => {
    const nativeTiming = { useNativeDriver: true, isInteraction: false } as const;
    const sequence = Animated.sequence([
      Animated.timing(loop, { toValue: 1, duration: 1100, easing: Easing.out(Easing.cubic), ...nativeTiming }),
      Animated.parallel([
        Animated.spring(cloche, { toValue: 1, friction: 7, tension: 120, ...nativeTiming }),
        Animated.spring(leaf, { toValue: 1, friction: 6, tension: 125, ...nativeTiming }),
        Animated.timing(beat, { toValue: 1, duration: 480, easing: Easing.out(Easing.cubic), ...nativeTiming }),
      ]),
      Animated.parallel([
        Animated.spring(wordmark, { toValue: 1, friction: 8, tension: 105, ...nativeTiming }),
        Animated.timing(manager, { toValue: 1, duration: 680, easing: Easing.out(Easing.cubic), ...nativeTiming }),
      ]),
    ]);
    sequence.start();
    const pulseLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1.035, duration: 950, easing: Easing.inOut(Easing.sin), ...nativeTiming }),
        Animated.timing(pulse, { toValue: 1, duration: 950, easing: Easing.inOut(Easing.sin), ...nativeTiming }),
      ]),
    );
    pulseLoop.start();
    return () => { sequence.stop(); pulseLoop.stop(); };
  }, [beat, cloche, leaf, loop, manager, pulse, wordmark]);

  const loopScale = loop.interpolate({ inputRange: [0, 1], outputRange: [0.72, 1] });
  const loopOpacity = loop.interpolate({ inputRange: [0, 0.35, 1], outputRange: [0.1, 0.8, 1] });
  const beatScale = beat.interpolate({ inputRange: [0, 0.4, 1], outputRange: [0.5, 1.12, 1] });
  const itemIn = (value: Animated.Value) => ({ opacity: value, transform: [{ scale: value.interpolate({ inputRange: [0, 1], outputRange: [0.2, 1] }) }, { translateY: value.interpolate({ inputRange: [0, 1], outputRange: [-14, 0] }) }] });
  const wordmarkStyle = { opacity: wordmark, transform: [{ translateX: wordmark.interpolate({ inputRange: [0, 1], outputRange: [-18, 0] }) }] };
  const managerStyle = { opacity: manager, transform: [{ scaleX: manager.interpolate({ inputRange: [0, 1], outputRange: [0.86, 1] }) }] };
  const pulseStyle = { transform: [{ scale: pulse }] };

  return (
    <Animated.View style={[styles.brandLockup, compact && styles.brandLockupCompact, pulseStyle]}>
      <View style={[styles.logoStage, compact && styles.logoStageCompact]}>
        <Animated.View style={[styles.outerLoop, compact && styles.outerLoopCompact, { opacity: loopOpacity, transform: [{ scale: loopScale }, { rotate: "-28deg" }] }]} />
        <Animated.View style={[styles.cloche, compact && styles.clocheCompact, itemIn(cloche)]} />
        <Animated.View style={[styles.clocheBase, compact && styles.clocheBaseCompact, itemIn(cloche)]} />
        <Animated.View style={[styles.leaf, compact && styles.leafCompact, itemIn(leaf)]} />
        <Animated.View style={[styles.heartbeat, compact && styles.heartbeatCompact, { opacity: beat, transform: [{ scaleX: beatScale }] }]}>
          <View style={styles.heartbeatLine} />
          <View style={styles.heartbeatSpike} />
        </Animated.View>
      </View>
      {!compact && (
        <View style={styles.wordmarkBlock}>
          <Animated.Text style={[styles.dietlyWordmark, wordmarkStyle]}>DIETLY</Animated.Text>
          <Animated.Text style={[styles.managerWordmark, managerStyle]}>MANAGER</Animated.Text>
        </View>
      )}
    </Animated.View>
  );
}

export default function EntryScreen() {
  const router = useRouter();
  const [stage, setStage] = useState<Stage>("intro");
  const [checking, setChecking] = useState(true);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    let mounted = true;
    const checkSession = async () => {
      const [user, localSession] = await Promise.all([Auth.getUserInfo(), AsyncStorage.getItem(OWNER_SESSION_KEY)]);
      if (!mounted) return;
      setChecking(false);
      if (user || localSession) {
        setTimeout(() => router.replace("/(tabs)"), 5200);
      } else {
        setTimeout(() => setStage("auth"), 5600);
      }
    };
    checkSession();
    return () => { mounted = false; };
  }, [router]);

  const continueWithEmail = async () => {
    setError("");
    if (!email.trim() || !email.includes("@")) {
      setError("Enter the email you use for your kitchen account.");
      return;
    }
    if (password.trim().length < 6) {
      setError("Use a password with at least 6 characters.");
      return;
    }
    setBusy(true);
    const user: Auth.User = {
      id: -1,
      openId: `owner:${email.trim().toLowerCase()}`,
      name: email.split("@")[0].replace(/[._-]/g, " "),
      email: email.trim().toLowerCase(),
      loginMethod: "email",
      lastSignedIn: new Date(),
    };
    await Auth.setUserInfo(user);
    await AsyncStorage.setItem(OWNER_SESSION_KEY, "email-session");
    setTimeout(() => router.replace("/(tabs)"), 280);
  };

  const continueWithGoogle = async () => {
    setError("");
    setBusy(true);
    try {
      await startOAuthLogin();
    } catch (loginError) {
      setBusy(false);
      setError(loginError instanceof Error ? loginError.message : "Google login is unavailable right now.");
    }
  };

  if (checking || stage === "intro") {
    return (
      <View style={styles.introScreen}>
        <BrandMark />
        <Animated.Text style={styles.introKicker}>THE OWNER OPERATING SYSTEM FOR HEALTHY FOOD</Animated.Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.authScreen} edges={["top", "bottom"]}>
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <ScrollView contentContainerStyle={styles.authScroll} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          <View style={styles.authTop}><BrandMark compact /><Text style={styles.authTopCaption}>FITBISTRO · OWNER CONSOLE</Text></View>
          <View style={styles.authCard}>
            <Text style={styles.authEyebrow}>WELCOME BACK, OPERATOR</Text>
            <Text style={styles.authTitle}>Run the kitchen smarter.</Text>
            <Text style={styles.authSubtitle}>Sign in to manage orders, memberships, inbox requests, and dispatch.</Text>

            <Pressable onPress={continueWithGoogle} disabled={busy} style={({ pressed }) => [styles.googleButton, pressed && styles.pressed, busy && styles.disabled]}>
              <View style={styles.googleBadge}><Text style={styles.googleG}>G</Text></View>
              <Text style={styles.googleText}>{busy ? "Opening secure sign in..." : "Continue with Google"}</Text>
            </Pressable>

            <View style={styles.divider}><View style={styles.dividerLine} /><Text style={styles.dividerText}>OR USE EMAIL</Text><View style={styles.dividerLine} /></View>

            <Text style={styles.fieldLabel}>WORK EMAIL</Text>
            <View style={styles.inputWrap}><Ionicons name="mail-outline" size={18} color={MUTED} /><TextInput value={email} onChangeText={setEmail} autoCapitalize="none" autoCorrect={false} keyboardType="email-address" placeholder="owner@fitbistro.in" placeholderTextColor="#7E8A92" style={styles.input} /></View>
            <Text style={styles.fieldLabel}>PASSWORD</Text>
            <View style={styles.inputWrap}><Ionicons name="lock-closed-outline" size={18} color={MUTED} /><TextInput value={password} onChangeText={setPassword} secureTextEntry={!showPassword} placeholder="Enter your password" placeholderTextColor="#7E8A92" style={styles.input} /><Pressable onPress={() => setShowPassword((value) => !value)} hitSlop={10}><Ionicons name={showPassword ? "eye-off-outline" : "eye-outline"} size={18} color={MUTED} /></Pressable></View>
            {error ? <Text style={styles.errorText}>{error}</Text> : null}
            <Pressable onPress={continueWithEmail} disabled={busy} style={({ pressed }) => [styles.emailButton, pressed && styles.pressed, busy && styles.disabled]}><Text style={styles.emailButtonText}>Open owner dashboard</Text><Ionicons name="arrow-forward" size={17} color={SLATE} /></Pressable>
            <Text style={styles.terms}>By continuing, you agree to DIETLY MANAGER&apos;s owner terms and privacy policy.</Text>
          </View>
          <View style={styles.authFooter}><View style={styles.footerDot} /><Text style={styles.footerText}>Your kitchen data stays in your workspace.</Text></View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  introScreen: { flex: 1, backgroundColor: SLATE, alignItems: "center", justifyContent: "center", padding: 30 },
  introKicker: { color: MUTED, fontSize: 9, fontWeight: "800", letterSpacing: 1.7, textAlign: "center", marginTop: 28 },
  brandLockup: { alignItems: "center", justifyContent: "center" },
  brandLockupCompact: { flexDirection: "row", justifyContent: "flex-start", gap: 12 },
  logoStage: { width: 132, height: 132, alignItems: "center", justifyContent: "center" },
  logoStageCompact: { width: 48, height: 48 },
  outerLoop: { position: "absolute", width: 112, height: 112, borderRadius: 56, borderWidth: 6, borderColor: MINT, borderRightColor: "transparent", borderTopColor: "transparent" },
  outerLoopCompact: { width: 42, height: 42, borderRadius: 21, borderWidth: 3 },
  cloche: { position: "absolute", width: 62, height: 38, borderRadius: 36, borderWidth: 6, borderColor: MINT, borderBottomColor: "transparent", top: 31 },
  clocheCompact: { width: 24, height: 15, borderRadius: 14, borderWidth: 3, top: 11 },
  clocheBase: { position: "absolute", width: 72, height: 6, borderRadius: 4, backgroundColor: MINT, top: 65 },
  clocheBaseCompact: { width: 28, height: 3, top: 24 },
  leaf: { position: "absolute", width: 23, height: 34, borderRadius: 22, backgroundColor: MINT, transform: [{ rotate: "42deg" }], top: 19, right: 13 },
  leafCompact: { width: 9, height: 14, borderRadius: 10, top: 7, right: 5 },
  heartbeat: { position: "absolute", width: 82, height: 28, top: 58, alignItems: "center", justifyContent: "center" },
  heartbeatCompact: { width: 31, height: 12, top: 22 },
  heartbeatLine: { position: "absolute", width: "100%", height: 3, borderRadius: 3, backgroundColor: MINT },
  heartbeatSpike: { position: "absolute", width: 12, height: 12, borderLeftWidth: 3, borderBottomWidth: 3, borderColor: MINT, transform: [{ rotate: "-45deg" }, { translateX: 2 }, { translateY: -3 }] },
  wordmarkBlock: { alignItems: "center", marginTop: 3 },
  dietlyWordmark: { color: WHITE, fontSize: 42, fontWeight: "900", letterSpacing: 5 },
  managerWordmark: { color: MINT, fontSize: 13, fontWeight: "900", letterSpacing: 5, marginTop: 2 },
  authScreen: { flex: 1, backgroundColor: SLATE },
  authScroll: { flexGrow: 1, paddingHorizontal: 20, paddingTop: 15, paddingBottom: 24 },
  authTop: { alignItems: "center", marginBottom: 20 },
  authTopCaption: { color: MUTED, fontSize: 9, fontWeight: "800", letterSpacing: 1.4, marginTop: 5 },
  authCard: { backgroundColor: "#F4F7F2", borderRadius: 26, padding: 22, shadowColor: "#000", shadowOpacity: 0.18, shadowRadius: 18, shadowOffset: { width: 0, height: 9 }, elevation: 5 },
  authEyebrow: { color: "#5D786A", fontSize: 9, fontWeight: "900", letterSpacing: 1.4, marginBottom: 9 },
  authTitle: { color: SLATE, fontSize: 30, lineHeight: 34, fontWeight: "900", letterSpacing: -0.9 },
  authSubtitle: { color: "#687570", fontSize: 13, lineHeight: 19, marginTop: 8, marginBottom: 22 },
  googleButton: { height: 52, borderRadius: 14, borderWidth: 1, borderColor: "#D3DDD5", backgroundColor: "#FFFFFF", flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10 },
  googleBadge: { width: 24, height: 24, borderRadius: 12, backgroundColor: "#F1F5F1", alignItems: "center", justifyContent: "center" },
  googleG: { color: "#4285F4", fontSize: 16, fontWeight: "900" },
  googleText: { color: SLATE, fontSize: 14, fontWeight: "800" },
  divider: { flexDirection: "row", alignItems: "center", gap: 10, marginVertical: 20 },
  dividerLine: { height: 1, backgroundColor: "#D8E0D9", flex: 1 },
  dividerText: { color: "#87948D", fontSize: 9, fontWeight: "900", letterSpacing: 1 },
  fieldLabel: { color: "#607169", fontSize: 9, fontWeight: "900", letterSpacing: 1.2, marginBottom: 7, marginTop: 2 },
  inputWrap: { minHeight: 52, borderRadius: 13, borderWidth: 1, borderColor: "#D5DED7", backgroundColor: "#FFFFFF", flexDirection: "row", alignItems: "center", paddingHorizontal: 14, gap: 10, marginBottom: 14 },
  input: { flex: 1, color: SLATE, fontSize: 14, minHeight: 50 },
  errorText: { color: "#B5544A", fontSize: 12, lineHeight: 17, marginBottom: 10 },
  emailButton: { minHeight: 54, borderRadius: 14, backgroundColor: MINT, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10, marginTop: 3 },
  emailButtonText: { color: SLATE, fontSize: 14, fontWeight: "900" },
  terms: { color: "#8A968F", fontSize: 10, lineHeight: 15, textAlign: "center", marginTop: 16 },
  authFooter: { flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 7, marginTop: "auto", paddingTop: 24 },
  footerDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: MINT },
  footerText: { color: "#9DA9AE", fontSize: 10 },
  pressed: { opacity: 0.82, transform: [{ scale: 0.99 }] },
  disabled: { opacity: 0.55 },
});
