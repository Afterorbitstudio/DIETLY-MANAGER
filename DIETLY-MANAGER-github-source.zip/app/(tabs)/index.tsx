import AsyncStorage from "@react-native-async-storage/async-storage";
import { Ionicons } from "@expo/vector-icons";
import { usePathname } from "expo-router";
import { useEffect, useState, useSyncExternalStore, type ComponentProps } from "react";
import {
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";

import { ScreenContainer } from "@/components/screen-container";

const STORAGE_KEY = "dietly-manager-state-v1";
const BRAND = "#7CFFB2";
const INK = "#0E1715";
const INK_PANEL = "#15231F";
const PARCHMENT = "#F4F1E9";
const MUTED = "#75837D";
const LINE = "#D8DED8";
const AMBER = "#F8C76A";
const CORAL = "#FF8C7A";
const WHITE = "#FFFFFF";

type IconName = ComponentProps<typeof Ionicons>["name"];
type TabName = "Prep" | "Wallets" | "WhatsApp" | "Delivery";
type Slot = "Lunch" | "Dinner";
type OrderStatus = "Queued" | "Prepped" | "Out for Delivery" | "Delivered";
type ModalKind = "topup" | "debit" | "pause" | "manifest" | null;

const SLOT_INFO: Record<Slot, string> = {
  Lunch: "12:00 PM – 2:00 PM",
  Dinner: "7:30 PM – 9:30 PM",
};

const STATUS_FLOW: OrderStatus[] = ["Queued", "Prepped", "Out for Delivery", "Delivered"];

interface MenuItem {
  id: string;
  name: string;
  shortName: string;
  price: number;
  protein: number;
  carbs: number;
  fat: number;
  accent: string;
}

interface Transaction {
  id: string;
  date: string;
  item: string;
  amount: number;
  balance: number;
  note?: string;
}

interface Subscriber {
  id: string;
  name: string;
  phone: string;
  area: string;
  goal: string;
  balance: number;
  cluster: string;
  deliveryNote: string;
  status: "Active" | "Paused";
  pauseStart?: string;
  resumeDate?: string;
  transactions: Transaction[];
}

interface KitchenOrder {
  id: string;
  subscriberId: string;
  subscriberName: string;
  itemId: string;
  itemName: string;
  slot: Slot;
  cluster: string;
  status: OrderStatus;
  calendarStatus?: "Scheduled" | "Paused";
  deliveryNote: string;
}

interface PersistedState {
  subscribers: Subscriber[];
  orders: KitchenOrder[];
}

const MENU_ITEMS: MenuItem[] = [
  {
    id: "chicken-bowl",
    name: "Grilled Chicken Quinoa Bowl",
    shortName: "Chicken Quinoa Bowl",
    price: 480,
    protein: 42,
    carbs: 38,
    fat: 16,
    accent: "#74E9A5",
  },
  {
    id: "tofu-scramble",
    name: "Smoky Tofu Scramble",
    shortName: "Tofu Scramble",
    price: 360,
    protein: 28,
    carbs: 24,
    fat: 18,
    accent: "#F8C76A",
  },
  {
    id: "keto-salad",
    name: "Keto Avocado Crunch Salad",
    shortName: "Keto Avocado Salad",
    price: 420,
    protein: 22,
    carbs: 14,
    fat: 30,
    accent: "#FF9A7E",
  },
  {
    id: "salmon-box",
    name: "Lemon Herb Salmon Box",
    shortName: "Salmon Box",
    price: 560,
    protein: 40,
    carbs: 32,
    fat: 22,
    accent: "#A9B8FF",
  },
];

const initialSubscribers: Subscriber[] = [
  {
    id: "rahul",
    name: "Rahul Verma",
    phone: "+91 98765 43210",
    area: "Indiranagar",
    goal: "Lean muscle",
    balance: 7400,
    cluster: "Indiranagar · 12th Main",
    deliveryNote: "Leave with security if unavailable",
    status: "Active",
    transactions: [
      {
        id: "rahul-seed-1",
        date: "12 Oct 2026 · 08:42",
        item: "Grilled Chicken Quinoa Bowl",
        amount: 480,
        balance: 7400,
        note: "Lunch delivery",
      },
      {
        id: "rahul-seed-2",
        date: "01 Oct 2026 · 09:10",
        item: "Monthly wallet top-up",
        amount: 10000,
        balance: 7880,
        note: "₹10,000 plan recharge",
      },
    ],
  },
  {
    id: "sneha",
    name: "Sneha Rao",
    phone: "+91 99801 22341",
    area: "Koramangala",
    goal: "Fat loss",
    balance: 9500,
    cluster: "Koramangala · 5th Block",
    deliveryNote: "Ring once; dog at home",
    status: "Active",
    transactions: [
      {
        id: "sneha-seed-1",
        date: "02 Oct 2026 · 10:05",
        item: "Monthly wallet top-up",
        amount: 10000,
        balance: 9500,
        note: "₹10,000 plan recharge",
      },
    ],
  },
  {
    id: "arjun",
    name: "Arjun Mehta",
    phone: "+91 98450 11827",
    area: "HSR Layout",
    goal: "High protein",
    balance: 8260,
    cluster: "HSR Layout · Sector 2",
    deliveryNote: "Call on arrival",
    status: "Active",
    transactions: [],
  },
  {
    id: "meera",
    name: "Meera Nair",
    phone: "+91 99000 77214",
    area: "Whitefield",
    goal: "Balanced",
    balance: 6120,
    cluster: "Whitefield · Palm Meadows",
    deliveryNote: "Gate pass with kitchen name",
    status: "Active",
    transactions: [],
  },
  {
    id: "kabir",
    name: "Kabir Shah",
    phone: "+91 98191 44209",
    area: "Jayanagar",
    goal: "Low carb",
    balance: 4380,
    cluster: "Jayanagar · 4th Block",
    deliveryNote: "Apartment 704, tower B",
    status: "Paused",
    pauseStart: "12 Oct 2026",
    resumeDate: "15 Oct 2026",
    transactions: [],
  },
  {
    id: "ananya",
    name: "Ananya Iyer",
    phone: "+91 97310 58031",
    area: "Marathahalli",
    goal: "Endurance",
    balance: 7340,
    cluster: "Marathahalli · SJR Park",
    deliveryNote: "Use service lift",
    status: "Active",
    transactions: [],
  },
  {
    id: "vikram",
    name: "Vikram Joshi",
    phone: "+91 98451 33081",
    area: "Bellandur",
    goal: "Muscle gain",
    balance: 8920,
    cluster: "Bellandur · Green Glen",
    deliveryNote: "Text before entering campus",
    status: "Active",
    transactions: [],
  },
];

const initialOrders: KitchenOrder[] = [
  {
    id: "order-1",
    subscriberId: "rahul",
    subscriberName: "Rahul Verma",
    itemId: "chicken-bowl",
    itemName: "Grilled Chicken Quinoa Bowl",
    slot: "Lunch",
    cluster: "Indiranagar · 12th Main",
    status: "Queued",
    deliveryNote: "Leave with security if unavailable",
  },
  {
    id: "order-2",
    subscriberId: "arjun",
    subscriberName: "Arjun Mehta",
    itemId: "chicken-bowl",
    itemName: "Grilled Chicken Quinoa Bowl",
    slot: "Lunch",
    cluster: "HSR Layout · Sector 2",
    status: "Prepped",
    deliveryNote: "Call on arrival",
  },
  {
    id: "order-3",
    subscriberId: "sneha",
    subscriberName: "Sneha Rao",
    itemId: "tofu-scramble",
    itemName: "Smoky Tofu Scramble",
    slot: "Lunch",
    cluster: "Koramangala · 5th Block",
    status: "Out for Delivery",
    deliveryNote: "Ring once; dog at home",
  },
  {
    id: "order-4",
    subscriberId: "meera",
    subscriberName: "Meera Nair",
    itemId: "keto-salad",
    itemName: "Keto Avocado Crunch Salad",
    slot: "Lunch",
    cluster: "Whitefield · Palm Meadows",
    status: "Queued",
    deliveryNote: "Gate pass with kitchen name",
  },
  {
    id: "order-5",
    subscriberId: "ananya",
    subscriberName: "Ananya Iyer",
    itemId: "chicken-bowl",
    itemName: "Grilled Chicken Quinoa Bowl",
    slot: "Dinner",
    cluster: "Marathahalli · SJR Park",
    status: "Queued",
    deliveryNote: "Use service lift",
  },
  {
    id: "order-6",
    subscriberId: "vikram",
    subscriberName: "Vikram Joshi",
    itemId: "keto-salad",
    itemName: "Keto Avocado Crunch Salad",
    slot: "Dinner",
    cluster: "Bellandur · Green Glen",
    status: "Prepped",
    deliveryNote: "Text before entering campus",
  },
  {
    id: "order-7",
    subscriberId: "kabir",
    subscriberName: "Kabir Shah",
    itemId: "salmon-box",
    itemName: "Lemon Herb Salmon Box",
    slot: "Dinner",
    cluster: "Jayanagar · 4th Block",
    status: "Delivered",
    deliveryNote: "Apartment 704, tower B",
  },
];

interface SharedState extends PersistedState {
  lastResponse: string;
}

const DEFAULT_RESPONSE = "Choose a webhook simulation above to preview the customer reply.";
let sharedState: SharedState = { subscribers: initialSubscribers, orders: initialOrders, lastResponse: DEFAULT_RESPONSE };
const sharedListeners = new Set<() => void>();
let hydrationPromise: Promise<void> | null = null;

const notifySharedState = () => sharedListeners.forEach((listener) => listener());

const persistSharedState = () => {
  AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(sharedState)).catch(() => undefined);
};

const commitSharedState = (updater: (current: SharedState) => SharedState) => {
  sharedState = updater(sharedState);
  notifySharedState();
  persistSharedState();
};

function useDietKitchenState() {
  const snapshot = useSyncExternalStore(
    (listener) => {
      sharedListeners.add(listener);
      return () => sharedListeners.delete(listener);
    },
    () => sharedState,
    () => sharedState,
  );

  useEffect(() => {
    if (hydrationPromise) return;
    hydrationPromise = AsyncStorage.getItem(STORAGE_KEY).then((value) => {
      if (!value) return;
      try {
        const parsed = JSON.parse(value) as Partial<SharedState>;
        if (parsed.subscribers?.length && parsed.orders?.length) {
          sharedState = {
            subscribers: parsed.subscribers,
            orders: parsed.orders,
            lastResponse: parsed.lastResponse ?? DEFAULT_RESPONSE,
          };
          notifySharedState();
        }
      } catch {
        // Keep the realistic seed data if a local draft is malformed.
      }
    }).catch(() => undefined);
  }, []);

  return snapshot;
}

const rupees = (amount: number) => `₹${Math.round(amount).toLocaleString("en-IN")}`;
const getMenuItem = (id: string) => MENU_ITEMS.find((item) => item.id === id) ?? MENU_ITEMS[0];
const getTodayLabel = () => "12 Oct 2026";

function Icon({ name, size = 18, color = INK }: { name: IconName; size?: number; color?: string }) {
  return <Ionicons name={name} size={size} color={color} />;
}

function StatusPill({ status }: { status: OrderStatus | "Active" | "Paused" }) {
  const config = {
    Queued: { color: MUTED, bg: "#EDF0EC", icon: "time-outline" as IconName },
    Prepped: { color: "#31765A", bg: "#DDF8E8", icon: "restaurant-outline" as IconName },
    "Out for Delivery": { color: "#9A6C17", bg: "#FFF1CF", icon: "bicycle-outline" as IconName },
    Delivered: { color: "#276E5B", bg: "#DDF8E8", icon: "checkmark-circle-outline" as IconName },
    Active: { color: "#276E5B", bg: "#DDF8E8", icon: "pulse-outline" as IconName },
    Paused: { color: "#9A6C17", bg: "#FFF1CF", icon: "pause-circle-outline" as IconName },
  }[status];

  return (
    <View style={[styles.statusPill, { backgroundColor: config.bg }]}>
      <Icon name={config.icon} size={12} color={config.color} />
      <Text style={[styles.statusPillText, { color: config.color }]}>{status}</Text>
    </View>
  );
}

function SectionLabel({ eyebrow, title, action, onAction }: { eyebrow: string; title: string; action?: string; onAction?: () => void }) {
  return (
    <View style={styles.sectionHeader}>
      <View style={styles.sectionTitleWrap}>
        <View style={styles.sectionRule} />
        <View>
          <Text style={styles.eyebrow}>{eyebrow}</Text>
          <Text style={styles.sectionTitle}>{title}</Text>
        </View>
      </View>
      {action ? (
        <Pressable onPress={onAction} style={({ pressed }) => [styles.textAction, pressed && styles.pressed]}>
          <Text style={styles.textActionText}>{action}</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

function MetricCard({ value, label, accent, icon }: { value: string; label: string; accent: string; icon: IconName }) {
  return (
    <View style={styles.metricCard}>
      <View style={[styles.metricIcon, { backgroundColor: `${accent}25` }]}>
        <Icon name={icon} size={16} color={accent} />
      </View>
      <Text style={styles.metricValue}>{value}</Text>
      <Text style={styles.metricLabel}>{label}</Text>
    </View>
  );
}

function AppHeader({ onNotifications }: { onNotifications: () => void }) {
  return (
    <View style={styles.header}>
      <View style={styles.brandRow}>
        <View style={styles.logoMark}>
          <View style={styles.logoLayerOne} />
          <View style={styles.logoLayerTwo} />
          <View style={styles.logoLeaf} />
        </View>
        <View>
          <Text style={styles.brandName}>DIETLY MANAGER</Text>
          <View style={styles.liveRow}>
            <View style={styles.liveDot} />
            <Text style={styles.liveText}>FITBISTRO · OWNER CONSOLE</Text>
          </View>
        </View>
      </View>
      <Pressable onPress={onNotifications} style={({ pressed }) => [styles.bellButton, pressed && styles.pressed]}>
        <Icon name="notifications-outline" size={19} color={WHITE} />
        <View style={styles.notificationDot} />
      </Pressable>
    </View>
  );
}

function PrepTab({ orders, subscribers, onAdvance, onToast }: { orders: KitchenOrder[]; subscribers: Subscriber[]; onAdvance: (orderId: string) => void; onToast: (message: string) => void }) {
  const [slot, setSlot] = useState<Slot>("Lunch");
  const slotOrders = orders.filter((order) => order.slot === slot && order.calendarStatus !== "Paused");
  const activeOrders = slotOrders.filter((order) => order.status !== "Delivered");
  const activeMembers = subscribers.filter((subscriber) => subscriber.status === "Active").length;
  const pausedMembers = subscribers.filter((subscriber) => subscriber.status === "Paused").length;
  const prepaidTotal = subscribers.reduce((sum, subscriber) => sum + subscriber.balance, 0);
  const counts = MENU_ITEMS.map((menu) => ({
    ...menu,
    count: slotOrders.filter((order) => order.itemId === menu.id).length,
  })).filter((item) => item.count > 0);
  const completed = slotOrders.filter((order) => order.status === "Delivered").length;

  return (
    <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
      <View style={styles.heroCopy}>
        <View style={styles.heroText}>
          <Text style={styles.dateText}>{getTodayLabel()} · SATURDAY SERVICE</Text>
          <Text style={styles.heroTitle}>Today&apos;s operations are on track.</Text>
          <Text style={styles.heroSubtitle}>Orders, membership revenue, and dispatch in one view.</Text>
        </View>
        <View style={styles.shiftBadge}>
          <Icon name="sunny-outline" size={15} color={AMBER} />
          <Text style={styles.shiftBadgeText}>{slot.toUpperCase()}</Text>
        </View>
      </View>

      <View style={styles.segmentedControl}>
        {(["Lunch", "Dinner"] as Slot[]).map((item) => (
          <Pressable key={item} onPress={() => setSlot(item)} style={[styles.segment, slot === item && styles.segmentActive]}>
            <Text style={[styles.segmentText, slot === item && styles.segmentTextActive]}>{item} slot</Text>
            <Text style={[styles.segmentMeta, slot === item && styles.segmentMetaActive]}>{SLOT_INFO[item]}</Text>
          </Pressable>
        ))}
      </View>

      <View style={styles.ownerPulse}>
        <View style={styles.ownerPulseHeader}><View><Text style={styles.ownerPulseEyebrow}>OWNER PULSE</Text><Text style={styles.ownerPulseTitle}>FitBistro at a glance</Text></View><View style={styles.ownerPulseBadge}><View style={styles.liveDot} /><Text style={styles.ownerPulseBadgeText}>LIVE</Text></View></View>
        <View style={styles.ownerPulseRow}><View style={styles.ownerPulseMetric}><Text style={styles.ownerPulseValue}>{activeMembers}</Text><Text style={styles.ownerPulseLabel}>active plans</Text></View><View style={styles.ownerPulseMetric}><Text style={styles.ownerPulseValue}>{rupees(prepaidTotal)}</Text><Text style={styles.ownerPulseLabel}>prepaid balance</Text></View><View style={styles.ownerPulseMetric}><Text style={styles.ownerPulseValue}>{pausedMembers}</Text><Text style={styles.ownerPulseLabel}>paused today</Text></View></View>
      </View>

      <View style={styles.metricsRow}>
        <MetricCard value={`${slotOrders.length}`} label="boxes on board" accent={BRAND} icon="layers-outline" />
        <MetricCard value={`${completed}/${slotOrders.length || 1}`} label="delivered" accent={AMBER} icon="checkmark-done-outline" />
        <MetricCard value={`${activeOrders.length}`} label="needs action" accent={CORAL} icon="flash-outline" />
      </View>

      <SectionLabel eyebrow="PREP VOLUME" title="Batch summary" action="View menu" onAction={() => onToast("Menu macros are shown in Wallets → Debit Meal.")} />
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.horizontalCards}>
        {counts.map((item) => (
          <View key={item.id} style={styles.batchCard}>
            <View style={[styles.batchAccent, { backgroundColor: item.accent }]} />
            <Text style={styles.batchCount}>{item.count}x</Text>
            <Text style={styles.batchName}>{item.shortName}</Text>
            <View style={styles.batchMacroRow}>
              <Text style={styles.batchMacro}>{item.protein}g P</Text>
              <Text style={styles.batchMacro}>{item.carbs}g C</Text>
              <Text style={styles.batchMacro}>{item.fat}g F</Text>
            </View>
          </View>
        ))}
        {counts.length === 0 ? <Text style={styles.emptyText}>No batches in this slot yet.</Text> : null}
      </ScrollView>

      <SectionLabel eyebrow="KITCHEN ORDER QUEUE" title={`${slot} deliveries`} action="Reset view" onAction={() => onToast("Queue is already showing today's live orders.")} />
      <View style={styles.queueCard}>
        <View style={styles.queueHeader}>
          <Text style={styles.queueHeaderText}>SUBSCRIBER / MEAL</Text>
          <Text style={styles.queueHeaderText}>NEXT STATUS</Text>
        </View>
        {slotOrders.map((order, index) => {
          const item = getMenuItem(order.itemId);
          const nextStatus = STATUS_FLOW[Math.min(STATUS_FLOW.indexOf(order.status) + 1, STATUS_FLOW.length - 1)];
          const isComplete = order.status === "Delivered";
          return (
            <View key={order.id} style={[styles.orderRow, index === slotOrders.length - 1 && styles.noBorder]}>
              <View style={[styles.orderColorBar, { backgroundColor: item.accent }]} />
              <View style={styles.orderMain}>
                <View style={styles.orderTopLine}>
                  <Text style={styles.orderName}>{order.subscriberName}</Text>
                  <StatusPill status={order.status} />
                </View>
                <Text style={styles.orderMeal}>{item.shortName} · {rupees(item.price)}</Text>
                <Text style={styles.orderCluster}>{order.cluster}</Text>
                <View style={styles.progressTrack}>
                  <View style={[styles.progressFill, { width: `${((STATUS_FLOW.indexOf(order.status) + 1) / STATUS_FLOW.length) * 100}%`, backgroundColor: isComplete ? "#61CB92" : BRAND }]} />
                </View>
              </View>
              <Pressable disabled={isComplete} onPress={() => onAdvance(order.id)} style={({ pressed }) => [styles.nextButton, isComplete && styles.nextButtonDone, pressed && styles.pressed]}>
                <Icon name={isComplete ? "checkmark" : "chevron-forward"} size={16} color={isComplete ? "#31765A" : INK} />
                <Text style={[styles.nextButtonText, isComplete && styles.nextButtonDoneText]}>{isComplete ? "Done" : nextStatus}</Text>
              </Pressable>
            </View>
          );
        })}
        {slotOrders.length === 0 ? <Text style={styles.emptyText}>No orders for this slot.</Text> : null}
      </View>
    </ScrollView>
  );
}

function WalletTab({
  subscribers,
  onOpenModal,
  onToast,
}: {
  subscribers: Subscriber[];
  onOpenModal: (kind: Exclude<ModalKind, null>, subscriberId: string) => void;
  onToast: (message: string) => void;
}) {
  const [query, setQuery] = useState("");
  const [selectedId, setSelectedId] = useState("rahul");
  const [showAudit, setShowAudit] = useState(true);
  const selected = subscribers.find((subscriber) => subscriber.id === selectedId) ?? subscribers[0];
  const filtered = subscribers.filter((subscriber) => `${subscriber.name} ${subscriber.area} ${subscriber.goal} ${subscriber.phone}`.toLowerCase().includes(query.toLowerCase()));
  const balancePercent = Math.min(100, Math.max(8, (selected.balance / 10000) * 100));

  return (
    <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
      <View style={styles.heroCopy}>
        <View style={styles.heroText}>
          <Text style={styles.dateText}>MEMBERSHIP LEDGER · 07 ACTIVE</Text>
          <Text style={styles.heroTitle}>Memberships in motion.</Text>
          <Text style={styles.heroSubtitle}>Track recurring plans, prepaid balances, and every owner action.</Text>
        </View>
        <View style={styles.walletHeroIcon}><Icon name="wallet-outline" size={20} color={BRAND} /></View>
      </View>

      <View style={styles.searchBar}>
        <Icon name="search-outline" size={18} color={MUTED} />
        <TextInput value={query} onChangeText={setQuery} placeholder="Search name, area, or goal" placeholderTextColor={MUTED} style={styles.searchInput} />
        <View style={styles.searchCount}><Text style={styles.searchCountText}>{filtered.length}</Text></View>
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.subscriberStrip}>
        {filtered.map((subscriber) => (
          <Pressable key={subscriber.id} onPress={() => setSelectedId(subscriber.id)} style={[styles.subscriberChip, selected.id === subscriber.id && styles.subscriberChipActive]}>
            <View style={[styles.avatar, selected.id === subscriber.id && styles.avatarActive]}><Text style={[styles.avatarText, selected.id === subscriber.id && styles.avatarTextActive]}>{subscriber.name.split(" ").map((part) => part[0]).join("")}</Text></View>
            <View style={styles.subscriberChipCopy}><Text style={[styles.subscriberChipName, selected.id === subscriber.id && styles.subscriberChipNameActive]} numberOfLines={1}>{subscriber.name}</Text><Text style={[styles.subscriberChipBalance, selected.id === subscriber.id && styles.subscriberChipBalanceActive]}>{rupees(subscriber.balance)}</Text><Text style={styles.subscriberChipDetails} numberOfLines={1}>{subscriber.area} · {subscriber.goal}</Text></View>
          </Pressable>
        ))}
      </ScrollView>

      <View style={styles.walletProfileCard}>
        <View style={styles.profileHeader}>
          <View style={styles.profileIdentity}>
            <View style={styles.largeAvatar}><Text style={styles.largeAvatarText}>{selected.name.split(" ").map((part) => part[0]).join("")}</Text></View>
            <View><Text style={styles.profileName}>{selected.name}</Text><Text style={styles.profileMeta}>{selected.phone} · {selected.area}</Text><Text style={styles.profileGoal}>{selected.goal} · {selected.cluster}</Text></View>
          </View>
          <StatusPill status={selected.status} />
        </View>
        <View style={styles.balancePanel}>
          <View style={styles.balanceTopLine}><Text style={styles.balanceLabel}>AVAILABLE WALLET</Text><Text style={styles.balancePlan}>₹10,000 monthly plan</Text></View>
          <Text style={styles.balanceValue}>{rupees(selected.balance)}</Text>
          <View style={styles.balanceTrack}><View style={[styles.balanceFill, { width: `${balancePercent}%` }]} /></View>
          <View style={styles.balanceBottomLine}><Text style={styles.balanceHint}>{Math.round(balancePercent)}% wallet remaining</Text><Text style={styles.balanceHint}>{selected.status === "Paused" ? `Resumes ${selected.resumeDate}` : "Auto-debit ready"}</Text></View>
        </View>
        <View style={styles.actionGrid}>
          <Pressable onPress={() => onOpenModal("topup", selected.id)} style={({ pressed }) => [styles.actionButton, styles.actionButtonPrimary, pressed && styles.pressed]}><Icon name="add-circle-outline" size={18} color={INK} /><Text style={styles.actionButtonPrimaryText}>Quick top-up</Text></Pressable>
          <Pressable onPress={() => onOpenModal("debit", selected.id)} style={({ pressed }) => [styles.actionButton, pressed && styles.pressed]}><Icon name="remove-circle-outline" size={18} color={INK} /><Text style={styles.actionButtonText}>Debit meal</Text></Pressable>
          <Pressable onPress={() => onOpenModal("pause", selected.id)} style={({ pressed }) => [styles.actionButton, pressed && styles.pressed]}><Icon name="pause-circle-outline" size={18} color={INK} /><Text style={styles.actionButtonText}>{selected.status === "Paused" ? "Edit pause" : "Pause plan"}</Text></Pressable>
        </View>
      </View>

      <SectionLabel eyebrow="AUDIT TRAIL" title="Wallet activity" action={showAudit ? "Collapse" : "Expand"} onAction={() => setShowAudit((value) => !value)} />
      {showAudit ? (
        <View style={styles.auditCard}>
          {selected.transactions.length === 0 ? <Text style={styles.emptyText}>No transactions yet. A meal debit or top-up will appear here.</Text> : selected.transactions.map((transaction, index) => (
            <View key={transaction.id} style={[styles.auditRow, index === selected.transactions.length - 1 && styles.noBorder]}>
              <View style={[styles.auditIcon, { backgroundColor: transaction.item.toLowerCase().includes("top-up") || transaction.item.toLowerCase().includes("wallet") ? "#DDF8E8" : "#FFF1CF" }]}><Icon name={transaction.item.toLowerCase().includes("top-up") || transaction.item.toLowerCase().includes("wallet") ? "arrow-up-outline" : "restaurant-outline"} size={15} color={transaction.item.toLowerCase().includes("top-up") || transaction.item.toLowerCase().includes("wallet") ? "#31765A" : "#9A6C17"} /></View>
              <View style={styles.auditCopy}><Text style={styles.auditItem}>{transaction.item}</Text><Text style={styles.auditDate}>{transaction.date}{transaction.note ? ` · ${transaction.note}` : ""}</Text></View>
              <View style={styles.auditAmount}><Text style={styles.auditAmountText}>{transaction.item.toLowerCase().includes("top-up") || transaction.item.toLowerCase().includes("wallet") ? "+" : "-"}{rupees(transaction.amount)}</Text><Text style={styles.auditBalance}>{rupees(transaction.balance)} left</Text></View>
            </View>
          ))}
        </View>
      ) : null}

      <SectionLabel eyebrow="MENU MACROS" title="Built for your plans" />
      <View style={styles.menuMacroCard}>
        {MENU_ITEMS.map((item, index) => <View key={item.id} style={[styles.menuMacroRow, index === MENU_ITEMS.length - 1 && styles.noBorder]}><View style={[styles.menuDot, { backgroundColor: item.accent }]} /><View style={styles.menuMacroCopy}><Text style={styles.menuMacroName}>{item.shortName}</Text><Text style={styles.menuMacroStats}>{item.protein}g protein · {item.carbs}g carbs · {item.fat}g fat</Text></View><Text style={styles.menuPrice}>{rupees(item.price)}</Text></View>)}
      </View>
    </ScrollView>
  );
}

function WhatsAppTab({ subscribers, onOpenModal, onToast, lastResponse, onRunSimulation }: { subscribers: Subscriber[]; onOpenModal: (kind: Exclude<ModalKind, null>, subscriberId: string) => void; onToast: (message: string) => void; lastResponse: string; onRunSimulation: (kind: "order" | "pause" | "balance", subscriberId: string) => void }) {
  const [targetId, setTargetId] = useState("rahul");
  const target = subscribers.find((subscriber) => subscriber.id === targetId) ?? subscribers[0];
  const examples = [
    { kind: "order" as const, label: "Order Chicken Bowl for lunch", icon: "restaurant-outline" as IconName, tone: "green" },
    { kind: "pause" as const, label: "Pause meal for tomorrow", icon: "pause-outline" as IconName, tone: "amber" },
    { kind: "balance" as const, label: "Check balance", icon: "wallet-outline" as IconName, tone: "blue" },
  ];

  return (
    <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
      <View style={styles.heroCopy}>
        <View style={styles.heroText}>
          <Text style={styles.dateText}>INBOX BRIDGE · WHATSAPP SIMULATOR</Text>
          <Text style={styles.heroTitle}>Messages into scheduled orders.</Text>
          <Text style={styles.heroSubtitle}>Turn owner inbox traffic into scheduled meals before it becomes a missed sale.</Text>
        </View>
        <View style={styles.whatsappHeroIcon}><Icon name="logo-whatsapp" size={20} color={BRAND} /></View>
      </View>

      <View style={styles.simulatorHeader}><View><Text style={styles.simulatorLabel}>SIMULATING AS</Text><Text style={styles.simulatorTarget}>{target.name}</Text></View><Pressable onPress={() => onToast("Connect WhatsApp in the production integrations panel.")} style={styles.connectionPill}><View style={styles.liveDot} /><Text style={styles.connectionText}>Webhook ready</Text></Pressable></View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.targetStrip}>{subscribers.map((subscriber) => <Pressable key={subscriber.id} onPress={() => setTargetId(subscriber.id)} style={[styles.targetChip, target.id === subscriber.id && styles.targetChipActive]}><Text style={[styles.targetChipText, target.id === subscriber.id && styles.targetChipTextActive]}>{subscriber.name}</Text></Pressable>)}</ScrollView>

      <SectionLabel eyebrow="INCOMING WEBHOOKS" title="Try a message" />
      <View style={styles.webhookCard}>
        {examples.map((example, index) => <Pressable key={example.kind} onPress={() => onRunSimulation(example.kind, targetId)} style={({ pressed }) => [styles.webhookRow, index === examples.length - 1 && styles.noBorder, pressed && styles.webhookRowPressed]}><View style={[styles.webhookIcon, { backgroundColor: example.tone === "green" ? "#DDF8E8" : example.tone === "amber" ? "#FFF1CF" : "#E6EEFF" }]}><Icon name={example.icon} size={18} color={example.tone === "green" ? "#31765A" : example.tone === "amber" ? "#9A6C17" : "#4A67A1"} /></View><View style={styles.webhookCopy}><Text style={styles.webhookTitle}>{example.label}</Text><Text style={styles.webhookSubtitle}>{example.kind === "order" ? "Parse · debit ₹480 · add to Lunch" : example.kind === "pause" ? "Update calendar · pause next delivery" : "Reply with live wallet balance"}</Text></View><Icon name="arrow-forward-circle-outline" size={22} color={INK} /></Pressable>)}
      </View>

      <View style={styles.responseCard}>
        <View style={styles.responseHeader}><View style={styles.responseTitleWrap}><Icon name="logo-whatsapp" size={17} color={BRAND} /><Text style={styles.responseTitle}>OUTBOUND TEMPLATE PREVIEW</Text></View><Text style={styles.responseTime}>NOW</Text></View>
        <View style={styles.chatBubble}><Text style={styles.chatBubbleText}>{lastResponse}</Text><View style={styles.chatMeta}><Text style={styles.chatMetaText}>DIETLY MANAGER · {target.phone}</Text><Icon name="checkmark-done" size={14} color={BRAND} /></View></View>
        <Text style={styles.responseHint}>This is the exact message the member receives after the simulation.</Text>
      </View>

      <View style={styles.inlineCallout}><Icon name="sparkles-outline" size={18} color={AMBER} /><View style={styles.calloutCopy}><Text style={styles.calloutTitle}>Make WhatsApp your fastest operator.</Text><Text style={styles.calloutText}>Pair these commands with your real webhook to turn “skip tomorrow” into a clean prep-line update.</Text></View></View>
    </ScrollView>
  );
}

function DeliveryTab({ orders, subscribers, onOpenManifest, onToast }: { orders: KitchenOrder[]; subscribers: Subscriber[]; onOpenManifest: () => void; onToast: (message: string) => void }) {
  const activeOrders = orders.filter((order) => order.status !== "Delivered" && order.calendarStatus !== "Paused");
  const groups = Array.from(activeOrders.reduce((map, order) => { const list = map.get(order.cluster) ?? []; list.push(order); map.set(order.cluster, list); return map; }, new Map<string, KitchenOrder[]>()));
  const inTransit = orders.filter((order) => order.status === "Out for Delivery").length;

  return (
    <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
      <View style={styles.heroCopy}>
        <View style={styles.heroText}><Text style={styles.dateText}>DISPATCH CONTROL · {groups.length} CLUSTERS</Text><Text style={styles.heroTitle}>Every order, one run.</Text><Text style={styles.heroSubtitle}>Bundle nearby members so riders spend less time between kitchens and homes.</Text></View>
        <View style={styles.deliveryHeroIcon}><Icon name="bicycle-outline" size={21} color={BRAND} /></View>
      </View>

      <View style={styles.deliveryKpiRow}><View style={styles.deliveryKpi}><Text style={styles.deliveryKpiValue}>{groups.length}</Text><Text style={styles.deliveryKpiLabel}>clusters today</Text></View><View style={styles.deliveryKpi}><Text style={styles.deliveryKpiValue}>{activeOrders.length}</Text><Text style={styles.deliveryKpiLabel}>boxes to route</Text></View><View style={styles.deliveryKpi}><Text style={styles.deliveryKpiValue}>{inTransit}</Text><Text style={styles.deliveryKpiLabel}>out now</Text></View></View>

      <View style={styles.manifestBanner}><View style={styles.manifestIcon}><Icon name="document-text-outline" size={20} color={INK} /></View><View style={styles.manifestCopy}><Text style={styles.manifestTitle}>Owner dispatch manifest</Text><Text style={styles.manifestSubtitle}>Printable list with member, phone, meal & notes.</Text></View><Pressable onPress={onOpenManifest} style={({ pressed }) => [styles.manifestButton, pressed && styles.pressed]}><Icon name="arrow-forward" size={15} color={INK} /></Pressable></View>

      <SectionLabel eyebrow="RIDER RUNS" title="Grouped by cluster" action="All notes" onAction={() => onToast("Notes are shown inside each delivery run.")} />
      {groups.map(([cluster, clusterOrders], index) => <View key={cluster} style={styles.clusterCard}><View style={styles.clusterHeader}><View><Text style={styles.clusterLabel}>RUN {String(index + 1).padStart(2, "0")}</Text><Text style={styles.clusterName}>{cluster}</Text></View><View style={styles.clusterCount}><Text style={styles.clusterCountValue}>{clusterOrders.length}</Text><Text style={styles.clusterCountLabel}>boxes</Text></View></View>{clusterOrders.map((order, orderIndex) => { const subscriber = subscribers.find((item) => item.id === order.subscriberId); const menu = getMenuItem(order.itemId); return <View key={order.id} style={[styles.deliveryRow, orderIndex === clusterOrders.length - 1 && styles.noBorder]}><View style={[styles.deliveryDot, { backgroundColor: menu.accent }]} /><View style={styles.deliveryCopy}><Text style={styles.deliveryName}>{order.subscriberName}</Text><Text style={styles.deliveryMeal}>{menu.shortName} · {subscriber?.phone}</Text><Text style={styles.deliveryNote}>{order.deliveryNote}</Text></View><StatusPill status={order.status} /></View>; })}</View>)}
      {groups.length === 0 ? <View style={styles.emptyPanel}><Icon name="checkmark-circle-outline" size={30} color="#31765A" /><Text style={styles.emptyPanelTitle}>All runs delivered</Text><Text style={styles.emptyPanelText}>The current board has no active delivery boxes.</Text></View> : null}
    </ScrollView>
  );
}

function ActionModal({ kind, subscriber, manifestOrders, manifestSubscribers, onClose, onTopUp, onDebit, onPause, onToast }: { kind: ModalKind; subscriber: Subscriber | undefined; manifestOrders: KitchenOrder[]; manifestSubscribers: Subscriber[]; onClose: () => void; onTopUp: (amount: number, note: string) => void; onDebit: (menuId: string) => void; onPause: (start: string, resume: string) => void; onToast: (message: string) => void }) {
  const [topUpAmount, setTopUpAmount] = useState<5000 | 10000>(5000);
  const [note, setNote] = useState("Monthly plan recharge");
  const [menuId, setMenuId] = useState(MENU_ITEMS[0].id);
  const [pauseStart, setPauseStart] = useState(subscriber?.pauseStart ?? getTodayLabel());
  const [resumeDate, setResumeDate] = useState(subscriber?.resumeDate ?? "13 Oct 2026");
  if (!kind || (kind !== "manifest" && !subscriber)) return null;
  const modalSubscriber = subscriber ?? initialSubscribers[0];
  const title = kind === "topup" ? "Quick top-up" : kind === "debit" ? "Debit a meal" : kind === "pause" ? "Pause subscription" : "Delivery manifest";
  const subtitle = kind === "topup" ? `Add funds to ${modalSubscriber.name}'s membership wallet.` : kind === "debit" ? `Choose the menu item to deduct from ${modalSubscriber.name}.` : kind === "pause" ? "Keep the pause window visible to the kitchen and member." : "A rider-ready export of today's active orders.";

  return (
    <Modal visible transparent animationType="slide" onRequestClose={onClose}>
      <KeyboardAvoidingView style={styles.modalBackdrop} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose} />
        <View style={styles.modalSheet}>
          <View style={styles.modalHandle} />
          <View style={styles.modalTitleRow}><View><Text style={styles.modalEyebrow}>{kind === "manifest" ? "DELIVERY HUB" : modalSubscriber.name.toUpperCase()}</Text><Text style={styles.modalTitle}>{title}</Text><Text style={styles.modalSubtitle}>{subtitle}</Text></View><Pressable onPress={onClose} style={styles.modalClose}><Icon name="close" size={19} color={INK} /></Pressable></View>
          {kind === "topup" ? <><Text style={styles.inputLabel}>SELECT AMOUNT</Text><View style={styles.amountRow}>{([5000, 10000] as const).map((amount) => <Pressable key={amount} onPress={() => setTopUpAmount(amount)} style={[styles.amountOption, topUpAmount === amount && styles.amountOptionActive]}><Text style={[styles.amountOptionText, topUpAmount === amount && styles.amountOptionTextActive]}>{rupees(amount)}</Text><Text style={[styles.amountOptionSub, topUpAmount === amount && styles.amountOptionSubActive]}>membership credit</Text></Pressable>)}</View><Text style={styles.inputLabel}>NOTE</Text><TextInput value={note} onChangeText={setNote} style={styles.modalInput} placeholder="What is this recharge for?" placeholderTextColor={MUTED} /><Pressable onPress={() => onTopUp(topUpAmount, note)} style={styles.modalPrimaryButton}><Icon name="add-circle-outline" size={18} color={INK} /><Text style={styles.modalPrimaryText}>Add {rupees(topUpAmount)} to membership</Text></Pressable></> : null}
          {kind === "debit" ? <><Text style={styles.inputLabel}>SELECT MENU ITEM</Text><View style={styles.modalMenuList}>{MENU_ITEMS.map((item) => <Pressable key={item.id} onPress={() => setMenuId(item.id)} style={[styles.modalMenuRow, menuId === item.id && styles.modalMenuRowActive]}><View style={[styles.menuDot, { backgroundColor: item.accent }]} /><View style={styles.menuMacroCopy}><Text style={[styles.menuMacroName, menuId === item.id && styles.modalMenuActiveText]}>{item.shortName}</Text><Text style={styles.menuMacroStats}>{item.protein}g P · {item.carbs}g C · {item.fat}g F</Text></View><Text style={[styles.menuPrice, menuId === item.id && styles.modalMenuActiveText]}>{rupees(item.price)}</Text><Icon name={menuId === item.id ? "checkmark-circle" : "ellipse-outline"} size={19} color={menuId === item.id ? "#31765A" : MUTED} /></Pressable>)}</View><Pressable onPress={() => onDebit(menuId)} style={styles.modalPrimaryButton}><Icon name="remove-circle-outline" size={18} color={INK} /><Text style={styles.modalPrimaryText}>Debit {rupees(getMenuItem(menuId).price)}</Text></Pressable></> : null}
          {kind === "pause" ? <><Text style={styles.inputLabel}>PAUSE START</Text><TextInput value={pauseStart} onChangeText={setPauseStart} style={styles.modalInput} placeholder="12 Oct 2026" placeholderTextColor={MUTED} /><Text style={styles.inputLabel}>RESUME DATE</Text><TextInput value={resumeDate} onChangeText={setResumeDate} style={styles.modalInput} placeholder="13 Oct 2026" placeholderTextColor={MUTED} /><View style={styles.pauseNotice}><Icon name="information-circle-outline" size={17} color="#9A6C17" /><Text style={styles.pauseNoticeText}>No prep slot will be created for this window.</Text></View><Pressable onPress={() => onPause(pauseStart, resumeDate)} style={styles.modalPrimaryButton}><Icon name="pause-circle-outline" size={18} color={INK} /><Text style={styles.modalPrimaryText}>Pause subscription</Text></Pressable></> : null}
          {kind === "manifest" ? <ManifestContent orders={manifestOrders} subscribers={manifestSubscribers} onClose={onClose} onToast={onToast} /> : null}
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

function ManifestContent({ orders, subscribers, onClose, onToast }: { orders: KitchenOrder[]; subscribers: Subscriber[]; onClose: () => void; onToast: (message: string) => void }) {
  const activeOrders = orders.filter((order) => order.status !== "Delivered" && order.calendarStatus !== "Paused");
  const manifestLines = activeOrders.map((order, index) => {
    const subscriber = subscribers.find((item) => item.id === order.subscriberId);
    const menu = getMenuItem(order.itemId);
    return `${index + 1}. ${order.subscriberName} · ${subscriber?.phone ?? "Phone on file"}\n   ${menu.shortName} · ${order.cluster}\n   ${order.deliveryNote}`;
  });
  const manifestText = manifestLines.length ? manifestLines.join("\n\n") : "No active boxes in the current delivery queue.";

  return <><View style={styles.manifestPreview}><Text style={styles.manifestPreviewTitle}>DIETLY MANAGER · DELIVERY MANIFEST</Text><Text style={styles.manifestPreviewDate}>{getTodayLabel()} · ACTIVE RUNS · {activeOrders.length} BOXES</Text><View style={styles.manifestPreviewLine} /><Text style={styles.manifestPreviewText}>{manifestText}</Text></View><View style={styles.manifestActionRow}><Pressable onPress={async () => { if (Platform.OS === "web") { (globalThis as { window?: { print?: () => void } }).window?.print?.(); onToast("Print dialog opened for the current manifest."); } else { await Share.share({ message: `DIETLY MANAGER Delivery Manifest\n\n${manifestText}` }); } }} style={styles.manifestExportButton}><Icon name="print-outline" size={17} color={INK} /><Text style={styles.manifestExportText}>Print / export</Text></Pressable><Pressable onPress={onClose} style={styles.manifestDismissButton}><Text style={styles.manifestDismissText}>Done</Text></Pressable></View></>;
}

export default function HomeScreen() {
  const pathname = usePathname();
  const routeTab: TabName = pathname.endsWith("/wallets") ? "Wallets" : pathname.endsWith("/whatsapp") ? "WhatsApp" : pathname.endsWith("/delivery") ? "Delivery" : "Prep";
  const { subscribers, orders, lastResponse } = useDietKitchenState();
  const [modal, setModal] = useState<{ kind: ModalKind; subscriberId?: string }>({ kind: null });
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    if (!toast) return;
    const timeout = setTimeout(() => setToast(null), 3200);
    return () => clearTimeout(timeout);
  }, [toast]);

  const selectedSubscriber = modal.subscriberId ? subscribers.find((subscriber) => subscriber.id === modal.subscriberId) : undefined;
  const activeTabLabel = ({ Prep: "Orders Command", Wallets: "Membership Ledger", WhatsApp: "Inbox Bridge", Delivery: "Dispatch Hub" })[routeTab];

  const showToast = (message: string) => setToast(message);
  const openModal = (kind: Exclude<ModalKind, null>, subscriberId?: string) => setModal({ kind, subscriberId });
  const closeModal = () => setModal({ kind: null });
  const updateSubscribers = (updater: (current: Subscriber[]) => Subscriber[]) => commitSharedState((current) => ({ ...current, subscribers: updater(current.subscribers) }));
  const updateOrders = (updater: (current: KitchenOrder[]) => KitchenOrder[]) => commitSharedState((current) => ({ ...current, orders: updater(current.orders) }));
  const updateResponse = (value: string) => commitSharedState((current) => ({ ...current, lastResponse: value }));

  const advanceOrder = (orderId: string) => {
    updateOrders((current) => current.map((order) => {
      if (order.id !== orderId) return order;
      const next = STATUS_FLOW[Math.min(STATUS_FLOW.indexOf(order.status) + 1, STATUS_FLOW.length - 1)];
      showToast(`${order.subscriberName} · ${next}`);
      return { ...order, status: next };
    }));
  };

  const addTransaction = (subscriber: Subscriber, transaction: Transaction) => ({ ...subscriber, balance: transaction.balance, transactions: [transaction, ...subscriber.transactions] });

  const handleTopUp = (amount: number, note: string) => {
    if (!selectedSubscriber) return;
    const transaction: Transaction = { id: `topup-${Date.now()}`, date: `${getTodayLabel()} · NOW`, item: "Monthly wallet top-up", amount, balance: selectedSubscriber.balance + amount, note };
    updateSubscribers((current) => current.map((subscriber) => subscriber.id === selectedSubscriber.id ? addTransaction(subscriber, transaction) : subscriber));
    showToast(`${selectedSubscriber.name} wallet topped up by ${rupees(amount)}.`);
    closeModal();
  };

  const handleDebit = (menuId: string) => {
    if (!selectedSubscriber) return;
    const menu = getMenuItem(menuId);
    if (selectedSubscriber.balance < menu.price) {
      showToast(`Not enough wallet balance for ${menu.shortName}.`);
      return;
    }
    const balance = selectedSubscriber.balance - menu.price;
    const transaction: Transaction = { id: `debit-${Date.now()}`, date: `${getTodayLabel()} · NOW`, item: menu.name, amount: menu.price, balance, note: "Manual meal debit" };
    updateSubscribers((current) => current.map((subscriber) => subscriber.id === selectedSubscriber.id ? addTransaction(subscriber, transaction) : subscriber));
    updateOrders((current) => [{ id: `order-${Date.now()}`, subscriberId: selectedSubscriber.id, subscriberName: selectedSubscriber.name, itemId: menu.id, itemName: menu.name, slot: "Lunch", cluster: selectedSubscriber.cluster, status: "Queued", calendarStatus: "Scheduled", deliveryNote: selectedSubscriber.deliveryNote }, ...current]);
    showToast(`${menu.shortName} added to today's Lunch queue.`);
    closeModal();
  };

  const handlePause = (start: string, resume: string) => {
    if (!selectedSubscriber) return;
    updateSubscribers((current) => current.map((subscriber) => subscriber.id === selectedSubscriber.id ? { ...subscriber, status: "Paused", pauseStart: start, resumeDate: resume } : subscriber));
    updateOrders((current) => current.map((order) => order.subscriberId === selectedSubscriber.id && order.status === "Queued" ? { ...order, calendarStatus: "Paused" } : order));
    showToast(`${selectedSubscriber.name}'s subscription is paused.`);
    closeModal();
  };

  const runSimulation = (kind: "order" | "pause" | "balance", subscriberId: string) => {
    const target = subscribers.find((subscriber) => subscriber.id === subscriberId) ?? subscribers[0];
    if (kind === "order") {
      const menu = getMenuItem("chicken-bowl");
      if (target.balance < menu.price) {
        showToast(`${target.name} needs a wallet top-up first.`);
        updateResponse(`We couldn't place your Grilled Chicken Quinoa Bowl because your wallet is below ${rupees(menu.price)}. Reply TOP UP to recharge.`);
        return;
      }
      const balance = target.balance - menu.price;
      const transaction: Transaction = { id: `wa-order-${Date.now()}`, date: `${getTodayLabel()} · NOW`, item: menu.name, amount: menu.price, balance, note: "WhatsApp order · Lunch" };
      updateSubscribers((current) => current.map((subscriber) => subscriber.id === target.id ? addTransaction(subscriber, transaction) : subscriber));
      updateOrders((current) => [{ id: `wa-order-${Date.now()}`, subscriberId: target.id, subscriberName: target.name, itemId: menu.id, itemName: menu.name, slot: "Lunch", cluster: target.cluster, status: "Queued", calendarStatus: "Scheduled", deliveryNote: target.deliveryNote }, ...current]);
      updateResponse(`Confirmed: 1 × Grilled Chicken Quinoa Bowl for lunch. ${rupees(menu.price)} debited. Your remaining balance is ${rupees(balance)}.`);
      showToast("WhatsApp order parsed and added to Lunch queue.");
    } else if (kind === "pause") {
      updateSubscribers((current) => current.map((subscriber) => subscriber.id === target.id ? { ...subscriber, status: "Paused", pauseStart: getTodayLabel(), resumeDate: "13 Oct 2026" } : subscriber));
      updateOrders((current) => current.map((order) => order.subscriberId === target.id && order.status === "Queued" ? { ...order, calendarStatus: "Paused" } : order));
      updateResponse("Done — tomorrow's meal is paused. Your subscription resumes on 13 Oct 2026. No wallet debit was made.");
      showToast(`Pause request applied to ${target.name}'s calendar.`);
    } else {
      updateResponse(`Your current balance is ${rupees(target.balance)}. Your next meal is ready to schedule.`);
      showToast("Live balance reply generated.");
    }
  };

  const screen = routeTab === "Prep" ? <PrepTab orders={orders} subscribers={subscribers} onAdvance={advanceOrder} onToast={showToast} /> : routeTab === "Wallets" ? <WalletTab subscribers={subscribers} onOpenModal={openModal} onToast={showToast} /> : routeTab === "WhatsApp" ? <WhatsAppTab subscribers={subscribers} onOpenModal={openModal} onToast={showToast} lastResponse={lastResponse} onRunSimulation={runSimulation} /> : <DeliveryTab orders={orders} subscribers={subscribers} onOpenManifest={() => openModal("manifest")} onToast={showToast} />;

  return (
    <ScreenContainer containerClassName="bg-[#F4F1E9]" safeAreaClassName="bg-[#F4F1E9]">
      <AppHeader onNotifications={() => showToast("You have 3 prep-line updates and 1 wallet alert.")} />
      <View style={styles.titleRail}><Text style={styles.titleRailText}>{activeTabLabel}</Text><View style={styles.titleRailLine} /></View>
      {screen}
      <ActionModal key={`${modal.kind}-${modal.subscriberId ?? "manifest"}`} kind={modal.kind} subscriber={selectedSubscriber} manifestOrders={orders} manifestSubscribers={subscribers} onClose={closeModal} onTopUp={handleTopUp} onDebit={handleDebit} onPause={handlePause} onToast={showToast} />
      {toast ? <View style={styles.toast}><View style={styles.toastIcon}><Icon name="checkmark" size={14} color={INK} /></View><Text style={styles.toastText}>{toast}</Text></View> : null}
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: { backgroundColor: INK, paddingHorizontal: 18, paddingVertical: 15, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  brandRow: { flexDirection: "row", alignItems: "center", gap: 11 },
  logoMark: { width: 34, height: 34, borderRadius: 10, backgroundColor: BRAND, overflow: "hidden", justifyContent: "center", alignItems: "center" },
  logoLayerOne: { width: 21, height: 5, backgroundColor: INK, borderRadius: 4, position: "absolute", top: 10 },
  logoLayerTwo: { width: 21, height: 5, backgroundColor: INK, borderRadius: 4, position: "absolute", top: 18 },
  logoLeaf: { width: 8, height: 8, borderRadius: 7, backgroundColor: INK, transform: [{ rotate: "45deg" }], position: "absolute", top: 7, right: 6 },
  brandName: { color: WHITE, fontSize: 17, fontWeight: "800", letterSpacing: -0.3 },
  liveRow: { flexDirection: "row", alignItems: "center", gap: 5, marginTop: 3 },
  liveDot: { width: 6, height: 6, borderRadius: 6, backgroundColor: BRAND },
  liveText: { color: "#9DB0A6", fontSize: 9, letterSpacing: 1.1, fontWeight: "700" },
  bellButton: { width: 35, height: 35, borderRadius: 18, borderWidth: 1, borderColor: "#31453C", justifyContent: "center", alignItems: "center" },
  notificationDot: { position: "absolute", top: 7, right: 8, width: 5, height: 5, borderRadius: 5, backgroundColor: CORAL },
  titleRail: { flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 18, paddingTop: 11 },
  titleRailText: { color: MUTED, fontSize: 10, fontWeight: "800", letterSpacing: 1.5, textTransform: "uppercase" },
  titleRailLine: { height: 1, flex: 1, backgroundColor: LINE },
  scrollContent: { paddingHorizontal: 18, paddingTop: 16, paddingBottom: 38 },
  heroCopy: { flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between", gap: 12, marginBottom: 18 },
  heroText: { flex: 1, minWidth: 0 },
  dateText: { color: MUTED, fontSize: 10, fontWeight: "800", letterSpacing: 1.35, marginBottom: 7 },
  heroTitle: { color: INK, fontSize: 27, lineHeight: 31, fontWeight: "800", letterSpacing: -0.8 },
  heroSubtitle: { color: MUTED, fontSize: 13, lineHeight: 19, marginTop: 6, maxWidth: 290 },
  shiftBadge: { backgroundColor: INK, borderRadius: 12, paddingHorizontal: 9, paddingVertical: 9, alignItems: "center", gap: 3 },
  shiftBadgeText: { color: BRAND, fontSize: 9, fontWeight: "800", letterSpacing: 0.7 },
  segmentedControl: { backgroundColor: "#E4E9E3", borderRadius: 15, padding: 4, flexDirection: "row", marginBottom: 16 },
  segment: { flex: 1, borderRadius: 11, paddingVertical: 9, paddingHorizontal: 8 },
  segmentActive: { backgroundColor: INK },
  segmentText: { color: MUTED, fontSize: 14, fontWeight: "800", textAlign: "center" },
  segmentTextActive: { color: WHITE },
  segmentMeta: { color: "#9AA49F", fontSize: 10, textAlign: "center", marginTop: 2 },
  segmentMetaActive: { color: "#B2C9BC" },
  ownerPulse: { backgroundColor: INK, borderRadius: 18, padding: 15, marginBottom: 16 },
  ownerPulseHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 15 },
  ownerPulseEyebrow: { color: BRAND, fontSize: 9, fontWeight: "800", letterSpacing: 1.2, marginBottom: 3 },
  ownerPulseTitle: { color: WHITE, fontSize: 17, fontWeight: "800" },
  ownerPulseBadge: { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 8, paddingVertical: 5, borderRadius: 10, backgroundColor: INK_PANEL },
  ownerPulseBadgeText: { color: BRAND, fontSize: 9, fontWeight: "800", letterSpacing: 0.7 },
  ownerPulseRow: { flexDirection: "row", gap: 8 },
  ownerPulseMetric: { flex: 1, borderTopWidth: 1, borderTopColor: "#294239", paddingTop: 9 },
  ownerPulseValue: { color: WHITE, fontSize: 17, fontWeight: "800" },
  ownerPulseLabel: { color: "#9DB0A6", fontSize: 9, marginTop: 3 },
  metricsRow: { flexDirection: "row", gap: 9, marginBottom: 23 },
  metricCard: { flex: 1, backgroundColor: WHITE, borderRadius: 15, padding: 12, borderWidth: 1, borderColor: "#E2E6E1", minHeight: 105 },
  metricIcon: { width: 27, height: 27, borderRadius: 9, justifyContent: "center", alignItems: "center", marginBottom: 9 },
  metricValue: { color: INK, fontSize: 21, fontWeight: "800", letterSpacing: -0.5 },
  metricLabel: { color: MUTED, fontSize: 10, lineHeight: 13, marginTop: 2 },
  sectionHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 11, marginTop: 2 },
  sectionTitleWrap: { flexDirection: "row", gap: 8, alignItems: "center" },
  sectionRule: { width: 3, height: 28, borderRadius: 4, backgroundColor: BRAND },
  eyebrow: { color: MUTED, fontSize: 9, fontWeight: "800", letterSpacing: 1.2, marginBottom: 2 },
  sectionTitle: { color: INK, fontSize: 18, fontWeight: "800", letterSpacing: -0.3 },
  textAction: { paddingVertical: 5, paddingHorizontal: 2 },
  textActionText: { color: "#31765A", fontSize: 11, fontWeight: "800" },
  horizontalCards: { gap: 10, paddingBottom: 22 },
  batchCard: { width: 150, backgroundColor: INK, borderRadius: 16, padding: 14, overflow: "hidden" },
  batchAccent: { width: 20, height: 4, borderRadius: 4, marginBottom: 16 },
  batchCount: { color: BRAND, fontSize: 24, fontWeight: "800", letterSpacing: -0.5 },
  batchName: { color: WHITE, fontSize: 13, fontWeight: "700", lineHeight: 17, marginTop: 3, minHeight: 36 },
  batchMacroRow: { flexDirection: "row", gap: 6, marginTop: 12 },
  batchMacro: { color: "#A6B9AF", fontSize: 9, fontWeight: "700" },
  queueCard: { backgroundColor: WHITE, borderRadius: 16, borderWidth: 1, borderColor: "#E2E6E1", overflow: "hidden", marginBottom: 22 },
  queueHeader: { backgroundColor: "#F8F9F6", paddingHorizontal: 13, paddingVertical: 10, flexDirection: "row", justifyContent: "space-between" },
  queueHeaderText: { color: MUTED, fontSize: 9, fontWeight: "800", letterSpacing: 0.9 },
  orderRow: { padding: 13, flexDirection: "row", borderBottomWidth: 1, borderBottomColor: "#EDF0EC", gap: 9, alignItems: "center" },
  orderColorBar: { width: 4, alignSelf: "stretch", borderRadius: 4 },
  orderMain: { flex: 1 },
  orderTopLine: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 5 },
  orderName: { color: INK, fontSize: 14, fontWeight: "800", flexShrink: 1 },
  orderMeal: { color: "#42524B", fontSize: 12, marginTop: 3 },
  orderCluster: { color: MUTED, fontSize: 10, marginTop: 2 },
  statusPill: { flexDirection: "row", alignItems: "center", gap: 4, borderRadius: 20, paddingVertical: 5, paddingHorizontal: 7 },
  statusPillText: { fontSize: 9, fontWeight: "800" },
  progressTrack: { height: 3, backgroundColor: "#E7ECE8", borderRadius: 3, marginTop: 9, overflow: "hidden" },
  progressFill: { height: "100%", borderRadius: 3 },
  nextButton: { backgroundColor: BRAND, borderRadius: 10, minWidth: 60, paddingVertical: 8, paddingHorizontal: 7, alignItems: "center", justifyContent: "center", gap: 2 },
  nextButtonDone: { backgroundColor: "#DDF8E8" },
  nextButtonText: { color: INK, fontSize: 9, fontWeight: "800", textAlign: "center" },
  nextButtonDoneText: { color: "#31765A" },
  noBorder: { borderBottomWidth: 0 },
  emptyText: { color: MUTED, fontSize: 13, lineHeight: 19, padding: 16 },
  searchBar: { backgroundColor: WHITE, borderWidth: 1, borderColor: LINE, borderRadius: 13, paddingHorizontal: 12, flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 11 },
  searchInput: { color: INK, fontSize: 13, flex: 1, paddingVertical: 11 },
  searchCount: { backgroundColor: "#E4E9E3", width: 25, height: 25, borderRadius: 9, justifyContent: "center", alignItems: "center" },
  searchCountText: { color: "#31765A", fontSize: 11, fontWeight: "800" },
  subscriberStrip: { gap: 8, paddingBottom: 16 },
  subscriberChip: { backgroundColor: WHITE, borderWidth: 1, borderColor: LINE, borderRadius: 13, padding: 8, flexDirection: "row", alignItems: "center", gap: 7, minWidth: 147 },
  subscriberChipActive: { backgroundColor: INK, borderColor: INK },
  avatar: { width: 28, height: 28, borderRadius: 10, backgroundColor: "#E4E9E3", justifyContent: "center", alignItems: "center" },
  avatarActive: { backgroundColor: BRAND },
  avatarText: { color: "#4C5D54", fontSize: 10, fontWeight: "800" },
  avatarTextActive: { color: INK },
  subscriberChipCopy: { flex: 1 },
  subscriberChipName: { color: INK, fontSize: 11, fontWeight: "800" },
  subscriberChipNameActive: { color: WHITE },
  subscriberChipBalance: { color: MUTED, fontSize: 10, marginTop: 2 },
  subscriberChipBalanceActive: { color: "#B2C9BC" },
  subscriberChipDetails: { color: "#98A59E", fontSize: 8, marginTop: 2 },
  walletProfileCard: { backgroundColor: INK, borderRadius: 18, padding: 15, marginBottom: 23 },
  profileHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", gap: 8 },
  profileIdentity: { flexDirection: "row", gap: 10, flex: 1 },
  largeAvatar: { width: 42, height: 42, borderRadius: 14, backgroundColor: BRAND, justifyContent: "center", alignItems: "center" },
  largeAvatarText: { color: INK, fontSize: 15, fontWeight: "800" },
  profileName: { color: WHITE, fontSize: 16, fontWeight: "800" },
  profileMeta: { color: "#A9B9B0", fontSize: 10, marginTop: 3 },
  profileGoal: { color: BRAND, fontSize: 10, fontWeight: "700", marginTop: 3 },
  balancePanel: { backgroundColor: INK_PANEL, borderRadius: 14, marginTop: 16, padding: 13 },
  balanceTopLine: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  balanceLabel: { color: "#90A398", fontSize: 9, fontWeight: "800", letterSpacing: 1.1 },
  balancePlan: { color: "#8EA198", fontSize: 9 },
  balanceValue: { color: WHITE, fontSize: 31, fontWeight: "800", letterSpacing: -1, marginTop: 7 },
  balanceTrack: { height: 5, backgroundColor: "#2D4037", borderRadius: 5, overflow: "hidden", marginTop: 9 },
  balanceFill: { height: "100%", backgroundColor: BRAND, borderRadius: 5 },
  balanceBottomLine: { flexDirection: "row", justifyContent: "space-between", marginTop: 7 },
  balanceHint: { color: "#9CB3A5", fontSize: 10 },
  actionGrid: { flexDirection: "row", gap: 7, marginTop: 12 },
  actionButton: { flex: 1, borderWidth: 1, borderColor: "#3B4B43", borderRadius: 10, paddingVertical: 10, alignItems: "center", justifyContent: "center", gap: 4 },
  actionButtonPrimary: { backgroundColor: BRAND, borderColor: BRAND },
  actionButtonText: { color: WHITE, fontSize: 10, fontWeight: "800" },
  actionButtonPrimaryText: { color: INK, fontSize: 10, fontWeight: "800" },
  auditCard: { backgroundColor: WHITE, borderRadius: 16, borderWidth: 1, borderColor: "#E2E6E1", overflow: "hidden", marginBottom: 22 },
  auditRow: { flexDirection: "row", alignItems: "center", padding: 12, borderBottomWidth: 1, borderBottomColor: "#EDF0EC", gap: 9 },
  auditIcon: { width: 29, height: 29, borderRadius: 10, justifyContent: "center", alignItems: "center" },
  auditCopy: { flex: 1 },
  auditItem: { color: INK, fontSize: 12, fontWeight: "800" },
  auditDate: { color: MUTED, fontSize: 9, lineHeight: 14, marginTop: 2 },
  auditAmount: { alignItems: "flex-end" },
  auditAmountText: { color: "#31765A", fontSize: 11, fontWeight: "800" },
  auditBalance: { color: MUTED, fontSize: 9, marginTop: 2 },
  menuMacroCard: { backgroundColor: WHITE, borderRadius: 16, borderWidth: 1, borderColor: "#E2E6E1", overflow: "hidden", marginBottom: 20 },
  menuMacroRow: { flexDirection: "row", alignItems: "center", padding: 12, gap: 9, borderBottomWidth: 1, borderBottomColor: "#EDF0EC" },
  menuDot: { width: 8, height: 8, borderRadius: 8 },
  menuMacroCopy: { flex: 1 },
  menuMacroName: { color: INK, fontSize: 12, fontWeight: "800" },
  menuMacroStats: { color: MUTED, fontSize: 9, marginTop: 3 },
  menuPrice: { color: INK, fontSize: 12, fontWeight: "800" },
  walletHeroIcon: { width: 39, height: 39, borderRadius: 13, backgroundColor: INK, justifyContent: "center", alignItems: "center" },
  whatsappHeroIcon: { width: 39, height: 39, borderRadius: 13, backgroundColor: INK, justifyContent: "center", alignItems: "center" },
  simulatorHeader: { backgroundColor: INK, borderRadius: 15, padding: 13, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  simulatorLabel: { color: "#91A79A", fontSize: 9, fontWeight: "800", letterSpacing: 1.1 },
  simulatorTarget: { color: WHITE, fontSize: 16, fontWeight: "800", marginTop: 4 },
  connectionPill: { borderWidth: 1, borderColor: "#365144", borderRadius: 20, paddingHorizontal: 8, paddingVertical: 6, flexDirection: "row", alignItems: "center", gap: 5 },
  connectionText: { color: BRAND, fontSize: 9, fontWeight: "800" },
  targetStrip: { gap: 7, paddingVertical: 11 },
  targetChip: { paddingHorizontal: 10, paddingVertical: 7, borderRadius: 18, backgroundColor: "#E4E9E3" },
  targetChipActive: { backgroundColor: BRAND },
  targetChipText: { color: "#52635A", fontSize: 10, fontWeight: "700" },
  targetChipTextActive: { color: INK },
  webhookCard: { backgroundColor: WHITE, borderRadius: 16, borderWidth: 1, borderColor: "#E2E6E1", overflow: "hidden", marginBottom: 20 },
  webhookRow: { flexDirection: "row", alignItems: "center", gap: 10, padding: 13, borderBottomWidth: 1, borderBottomColor: "#EDF0EC" },
  webhookRowPressed: { backgroundColor: "#F4F8F3" },
  webhookIcon: { width: 35, height: 35, borderRadius: 12, justifyContent: "center", alignItems: "center" },
  webhookCopy: { flex: 1 },
  webhookTitle: { color: INK, fontSize: 13, fontWeight: "800" },
  webhookSubtitle: { color: MUTED, fontSize: 10, marginTop: 3 },
  responseCard: { backgroundColor: INK, borderRadius: 17, padding: 14, marginBottom: 14 },
  responseHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 12 },
  responseTitleWrap: { flexDirection: "row", alignItems: "center", gap: 6 },
  responseTitle: { color: BRAND, fontSize: 9, fontWeight: "800", letterSpacing: 1.1 },
  responseTime: { color: "#8FA298", fontSize: 9, fontWeight: "800" },
  chatBubble: { backgroundColor: "#21342B", borderRadius: 14, borderTopLeftRadius: 4, padding: 12 },
  chatBubbleText: { color: WHITE, fontSize: 13, lineHeight: 20 },
  chatMeta: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 9 },
  chatMetaText: { color: "#91A79A", fontSize: 9 },
  responseHint: { color: "#8FA298", fontSize: 10, lineHeight: 15, marginTop: 10 },
  inlineCallout: { flexDirection: "row", gap: 9, backgroundColor: "#FFF5DD", borderRadius: 15, padding: 13, marginBottom: 20 },
  calloutCopy: { flex: 1 },
  calloutTitle: { color: "#6F511B", fontSize: 12, fontWeight: "800" },
  calloutText: { color: "#92733A", fontSize: 10, lineHeight: 15, marginTop: 3 },
  deliveryHeroIcon: { width: 39, height: 39, borderRadius: 13, backgroundColor: INK, justifyContent: "center", alignItems: "center" },
  deliveryKpiRow: { flexDirection: "row", gap: 8, marginBottom: 16 },
  deliveryKpi: { flex: 1, backgroundColor: WHITE, borderRadius: 14, borderWidth: 1, borderColor: "#E2E6E1", padding: 12 },
  deliveryKpiValue: { color: INK, fontSize: 24, fontWeight: "800" },
  deliveryKpiLabel: { color: MUTED, fontSize: 10, marginTop: 3 },
  manifestBanner: { backgroundColor: BRAND, borderRadius: 16, padding: 12, flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 23 },
  manifestIcon: { width: 34, height: 34, backgroundColor: "#B8FFD2", borderRadius: 11, justifyContent: "center", alignItems: "center" },
  manifestCopy: { flex: 1 },
  manifestTitle: { color: INK, fontSize: 13, fontWeight: "800" },
  manifestSubtitle: { color: "#31694D", fontSize: 10, marginTop: 3 },
  manifestButton: { width: 32, height: 32, borderRadius: 11, backgroundColor: INK, justifyContent: "center", alignItems: "center" },
  clusterCard: { backgroundColor: WHITE, borderRadius: 16, borderWidth: 1, borderColor: "#E2E6E1", overflow: "hidden", marginBottom: 12 },
  clusterHeader: { padding: 13, flexDirection: "row", alignItems: "center", justifyContent: "space-between", backgroundColor: "#F8F9F6" },
  clusterLabel: { color: "#31765A", fontSize: 9, fontWeight: "800", letterSpacing: 1 },
  clusterName: { color: INK, fontSize: 14, fontWeight: "800", marginTop: 3 },
  clusterCount: { alignItems: "flex-end" },
  clusterCountValue: { color: INK, fontSize: 18, fontWeight: "800" },
  clusterCountLabel: { color: MUTED, fontSize: 9 },
  deliveryRow: { flexDirection: "row", alignItems: "center", gap: 9, padding: 12, borderBottomWidth: 1, borderBottomColor: "#EDF0EC" },
  deliveryDot: { width: 8, height: 8, borderRadius: 8 },
  deliveryCopy: { flex: 1 },
  deliveryName: { color: INK, fontSize: 12, fontWeight: "800" },
  deliveryMeal: { color: "#52635A", fontSize: 10, marginTop: 3 },
  deliveryNote: { color: MUTED, fontSize: 9, marginTop: 3 },
  emptyPanel: { backgroundColor: WHITE, borderRadius: 16, padding: 28, alignItems: "center", marginBottom: 20 },
  emptyPanelTitle: { color: INK, fontSize: 16, fontWeight: "800", marginTop: 8 },
  emptyPanelText: { color: MUTED, fontSize: 12, marginTop: 4 },
  modalBackdrop: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(14,23,21,0.52)" },
  modalSheet: { backgroundColor: PARCHMENT, borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingHorizontal: 18, paddingTop: 9, paddingBottom: Platform.OS === "ios" ? 28 : 18, maxHeight: "88%" },
  modalHandle: { alignSelf: "center", width: 40, height: 4, backgroundColor: "#C1C9C2", borderRadius: 4, marginBottom: 16 },
  modalTitleRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", gap: 10, marginBottom: 18 },
  modalEyebrow: { color: MUTED, fontSize: 9, fontWeight: "800", letterSpacing: 1.1 },
  modalTitle: { color: INK, fontSize: 23, fontWeight: "800", letterSpacing: -0.5, marginTop: 3 },
  modalSubtitle: { color: MUTED, fontSize: 12, lineHeight: 17, marginTop: 5, maxWidth: 290 },
  modalClose: { width: 32, height: 32, borderRadius: 11, backgroundColor: WHITE, justifyContent: "center", alignItems: "center" },
  inputLabel: { color: MUTED, fontSize: 9, fontWeight: "800", letterSpacing: 1.1, marginBottom: 7, marginTop: 4 },
  amountRow: { flexDirection: "row", gap: 9, marginBottom: 15 },
  amountOption: { flex: 1, borderWidth: 1, borderColor: LINE, borderRadius: 13, padding: 12, backgroundColor: WHITE },
  amountOptionActive: { borderColor: INK, backgroundColor: INK },
  amountOptionText: { color: INK, fontSize: 16, fontWeight: "800" },
  amountOptionTextActive: { color: BRAND },
  amountOptionSub: { color: MUTED, fontSize: 10, marginTop: 3 },
  amountOptionSubActive: { color: "#AFC8B9" },
  modalInput: { backgroundColor: WHITE, borderColor: LINE, borderWidth: 1, borderRadius: 12, color: INK, fontSize: 13, paddingHorizontal: 12, paddingVertical: 11, marginBottom: 14 },
  modalPrimaryButton: { backgroundColor: BRAND, borderRadius: 13, paddingVertical: 13, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 7, marginTop: 5 },
  modalPrimaryText: { color: INK, fontSize: 13, fontWeight: "800" },
  modalMenuList: { backgroundColor: WHITE, borderRadius: 15, overflow: "hidden", borderWidth: 1, borderColor: LINE, marginBottom: 14 },
  modalMenuRow: { flexDirection: "row", alignItems: "center", gap: 8, padding: 11, borderBottomWidth: 1, borderBottomColor: "#EDF0EC" },
  modalMenuRowActive: { backgroundColor: "#F0FBF3" },
  modalMenuActiveText: { color: "#276E5B" },
  pauseNotice: { flexDirection: "row", alignItems: "center", gap: 7, backgroundColor: "#FFF1CF", borderRadius: 11, padding: 10, marginBottom: 8 },
  pauseNoticeText: { color: "#806020", fontSize: 10, flex: 1 },
  manifestPreview: { backgroundColor: WHITE, borderRadius: 15, borderWidth: 1, borderColor: LINE, padding: 13, marginBottom: 13 },
  manifestPreviewTitle: { color: INK, fontSize: 10, fontWeight: "800", letterSpacing: 0.6 },
  manifestPreviewDate: { color: MUTED, fontSize: 9, marginTop: 4 },
  manifestPreviewLine: { height: 1, backgroundColor: LINE, marginVertical: 10 },
  manifestPreviewText: { color: "#42524B", fontSize: 11, lineHeight: 17 },
  manifestActionRow: { flexDirection: "row", gap: 8 },
  manifestExportButton: { flex: 1, backgroundColor: BRAND, borderRadius: 12, paddingVertical: 12, flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 6 },
  manifestExportText: { color: INK, fontSize: 12, fontWeight: "800" },
  manifestDismissButton: { paddingHorizontal: 17, borderRadius: 12, backgroundColor: WHITE, justifyContent: "center", alignItems: "center" },
  manifestDismissText: { color: INK, fontSize: 12, fontWeight: "800" },
  toast: { position: "absolute", bottom: 13, left: 18, right: 18, backgroundColor: INK, borderRadius: 13, padding: 11, flexDirection: "row", alignItems: "center", gap: 8, shadowColor: "#000", shadowOpacity: 0.16, shadowRadius: 8, elevation: 4 },
  toastIcon: { width: 23, height: 23, backgroundColor: BRAND, borderRadius: 8, justifyContent: "center", alignItems: "center" },
  toastText: { color: WHITE, fontSize: 11, fontWeight: "700", flex: 1 },
  pressed: { opacity: 0.72 },
});
