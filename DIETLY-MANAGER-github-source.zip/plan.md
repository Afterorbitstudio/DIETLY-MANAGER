# DIETLY MANAGER — B2B Owner Dashboard Plan

## Product scope
DIETLY MANAGER is a portrait-first owner console for niche protein-food and healthy meal businesses such as FitBistro. It helps owners schedule daily orders, manage memberships and prepaid balances, turn WhatsApp messages into scheduled meals, and coordinate dispatch from one operating view.

The app now opens with a dark slate animated DIETLY MANAGER brand reveal lasting at least five seconds: the emerald circular loop draws in, the heartbeat pulses through the center, the cloche and leaf spring into place, and the DIETLY / MANAGER wordmark resolves before transitioning into owner authorization. The authorization surface offers the real managed Google OAuth route plus a local email/password owner-entry flow for this prototype.

## Implementation approach
- Keep the fixed managed Expo Router / React Native / TypeScript / NativeWind starter and existing four-tab route structure.
- Reframe the existing operational modules as owner workflows: Orders Command, Membership Ledger, Inbox Bridge, and Dispatch Hub.
- Preserve local AsyncStorage mock persistence so owner mutations survive reloads without introducing unnecessary backend schema work for this prototype.
- Keep typed entities for members, membership transactions, menus, scheduled orders, pause windows, and dispatch clusters.
- Add an Owner Pulse module to the orders screen showing active plans, prepaid balance, and paused members for the sample FitBistro business.
- Keep actions thumb-friendly: status progression, membership top-up, meal debit, pause/resume dates, WhatsApp simulations, and manifest export remain available in focused sheets.
- Add a first-run authorization gate with Google and email/password options, plus a five-second minimum animated intro before the dashboard.

## Design direction
- **Design movement:** Swiss editorial operations UI with a premium nutrition-tech signal.
- **Core principles:** owner-first clarity, dense but breathable records, calm urgency, and thumb-first control.
- **Color philosophy:** deep ink for a serious B2B command center, parchment for scanability, emerald for healthy business status, and amber/coral for attention.
- **Layout paradigm:** vertical command rail with a branded owner header, business pulse, slot switcher, operational stack, and persistent bottom task switcher.
- **Signature elements:** uppercase ticket labels with emerald rules, dark owner pulse cards, thin balance rails, and cluster-based dispatch cards.
- **Interaction philosophy:** every tap should either schedule, account for, pause, or move an order forward; use short feedback toasts and controlled modals.
- **Typography:** system sans, bold 27pt hero headlines, 17–18pt section titles, compact uppercase metadata, and heavy rupee figures.
- **Brand essence:** “The owner control room for subscription food businesses.” Personality: steady, sharp, nourishing.
- **Brand voice:** direct and operational. Example lines: “Today’s operations are on track.” and “Turn a message into a scheduled order.”
- **Wordmark/logo:** retain the stacked bowl-and-leaf mark while using the DIETLY MANAGER wordmark and FITBISTRO owner-console context.
- **Signature color:** `#7CFFB2` emerald.

## Product behavior
- Orders Command supports Lunch and Dinner slot filters, prep volume, status progression `Queued → Prepped → Out for Delivery → Delivered`, and the FitBistro Owner Pulse.
- Membership Ledger supports searchable member records, active/paused status, wallet balance, ₹5,000/₹10,000 membership credits with notes, meal debits, audit history, and pause/resume dates.
- Inbox Bridge simulates order, pause, and balance messages for the selected member and updates the shared state and outbound response preview.
- Dispatch Hub groups active orders by cluster and creates a current-data owner dispatch manifest suitable for print/export.
- Seed data remains realistic for a seven-member FitBistro business, including Rahul Verma at ₹7,400 and Sneha Rao at ₹9,500.

## Project structure
- `app/(tabs)/index.tsx` — owner dashboard shell, typed mock data, persistence, owner pulse, tabs, modals, and mutations.
- `app/(tabs)/_layout.tsx` — owner navigation labels and tab icons.
- `app/(tabs)/wallets.tsx`, `whatsapp.tsx`, `delivery.tsx` — route wrappers for the shared owner shell.
- `app.config.ts` — DIETLY MANAGER application branding and preserved native identifiers.
- `assets/images/*` — launcher and splash assets.
- `TODO.md` — concrete B2B deliverables.

## Build workflow
1. Keep host-managed TypeScript diagnostics registered.
2. Implement in the fixed managed Expo starter.
3. Run `pnpm check` and `pnpm lint`.
4. Start Metro/API on the fixed 8081/3000 ports and verify portrait preview routes.
5. Commit and push the accepted source to the canonical managed `main` branch.
